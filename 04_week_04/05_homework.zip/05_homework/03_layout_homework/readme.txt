Aufgabe 3: Layout

Erstelle das folgende Layout nach bestem Wissen und Gewissen nach

Für diese Übung musst du die gesamte Projektstruktur selbst erstellen.
Du brauchst eine index.html-Datei, einen css-Ordner mit einer Reset- und einer Style-Datei und einen Bilder-Ordner mit allen mitgelieferten Bildern (In "images" Ordener).

Colors: 
Black: #000
Pink: #ff4069
Yellow: #ffd171
Orange: #fda742
White: #fff

Fonts: 
Indie Flower
https://fonts.google.com/specimen/Indie+Flower
Variations

Icons:
Font Awesome: https://fontawesome.com/
ODER 
JAM: https://jam-icons.com/

Images:
In "images" Ordener